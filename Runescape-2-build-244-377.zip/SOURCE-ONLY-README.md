# RuneScape 2 Vita — approved build244 source-only export

Exported from the hash-verified approved build244 source snapshot. Source files retain their exact original bytes. No Slayer development changes are included.

Includes native C source/headers/includes, save-system source (the save/ directory contains code, not player saves), build scripts and JavaScript server code. The active server bundle is server.bundle.npc-unload.js. The original snapshot also contains server.bundle.tickparts.js as reference code.

No VPK, ELF, executable/object/library, cache, map/resource pack, standalone image/audio/model, shader binary, player save or test report is included. Five headers containing embedded user-supplied image/alpha-mask artwork have also been omitted. UI layout/geometry tables and source references to resource IDs remain code.

This is a source-only research/export package, not a self-contained build or playable game. Compiling requires the omitted image headers/resources and external toolchain/dependencies. Build scripts are preserved for reference and have not been executed; their original local paths may require adjustment.

SOURCE-MANIFEST.json identifies the original source archive, every included file hash, and the exact exclusions. The approved checkpoint, installed game and saves were not modified.
